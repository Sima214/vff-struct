# Εργασία για Δομές Δεδομένων 2017-18

[![Build Status](https://travis-ci.com/Sima214/vff-struct.svg?token=kaPtZHgAN2NhuaEpazT2&branch=master)](https://travis-ci.com/Sima214/vff-struct)

[Εκφώνηση.](https://elearning.auth.gr/pluginfile.php/458651/mod_resource/content/5/assignment_2017-2018.pdf)
