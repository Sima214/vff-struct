#ifndef DFS_STRUCT_HPP
#define DFS_STRUCT_HPP

#include <dispatch/icommandable.hpp>

int calculateConnectivity(dispatch::ICommandable*);

#endif /*DFS_STRUCT_HPP*/